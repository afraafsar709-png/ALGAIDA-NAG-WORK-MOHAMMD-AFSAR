ALGAIDA NAG WORK - STARTER PROJECT
Owner display: MOHAMMD AFSAR

IMPORTANT:
This project includes the app interface, Firebase email/password login, cloud bills, employee salary requests, admin approval, dark/light mode and a GitHub Actions APK build workflow.

BEFORE USING:
1. Create a Firebase project at https://console.firebase.google.com/
2. Add a Web App and copy its Firebase config.
3. Replace placeholders in www/firebase-config.js.
4. Enable Authentication > Email/Password.
5. Create Firestore Database.
6. Publish firestore.rules from this project.
7. Create the first employee account in the app.
8. In Firestore, open users collection, open that employee UID document and change role from employee to admin. Do this ONLY for the trusted admin account. Employee accounts must remain role=employee.
9. Commit and push all files to GitHub main branch. GitHub Actions will build an APK artifact.

ADMIN APPROVAL:
The admin account can log in on a different phone and approve/reject salary requests. Both phones need internet and use the same Firebase project.

SECURITY NOTE:
Do not share Firebase console access or admin login. Never make a user admin by editing app-side code. The first admin role assignment must be done by the project owner in Firebase Console.

CURRENT STARTER LIMITATIONS:
- Profile picture is stored as a data URL in Firestore; use a small image. A production version should use Firebase Storage.
- This starter is a foundation, not a fully audited payroll/accounting system. Test with sample records before real business use.
- Firebase config values are public app identifiers, but Firestore security rules and Authentication are essential.
