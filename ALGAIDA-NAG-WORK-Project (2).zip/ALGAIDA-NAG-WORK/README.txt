ALGAIDA NAG WORK
MOHAMMD AFSAR

Included:
- Mobile-friendly dashboard and invoice search
- Bill number, model number, customer and date
- Booking amount and work amount kept separate
- Live material calculation:
    Nag: 1440 = 17 AED
    Crystal: 200 = 10 AED
    BN: 200 = 10 AED
- Separate ratio calculator: splits total quantity by user-entered ratio parts
- Dark/light mode
- Profile picture upload and display name
- Local sign-up/login with PBKDF2 password hashing
- Change password
- Business report and CSV export
- Installable PWA files

HOW TO RUN:
1. Extract this ZIP.
2. Open index.html in a modern browser, or upload the folder to GitHub Pages / Netlify.
3. For install/offline features, host it over HTTPS and use the browser's Add to Home Screen / Install App option.

IMPORTANT DATA & SECURITY NOTE:
This is a browser-based starter app. Accounts, invoices and profile pictures are stored in the browser on that device only; they do not sync between phones or users and may be lost if browser site data is cleared. Passwords are PBKDF2-hashed, but this is not a replacement for a secure server-side authentication system. Do not use it for sensitive real business records until a secure backend, access controls and backups are added.

RATIO CALCULATOR:
Enter total quantity and the ratio parts for Nag, Crystal and BN. Example 1:1:1 divides the total equally across the three materials. Each resulting quantity is priced using the rates above.
